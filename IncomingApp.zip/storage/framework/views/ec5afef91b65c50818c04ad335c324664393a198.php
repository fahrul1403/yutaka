<footer class="footer footer-black  footer-white ">
    <div class="container-fluid">
        <div class="row">
            <nav class="footer-nav">
                <ul>
                    <li>
                        <a href="https://www.creative-tim.com" target="_blank"><?php echo e(__('Creative Tim')); ?></a>
                    </li>
                    <li>
                        <a href="https://updivision.com" target="_blank"><?php echo e(__('UpDivision')); ?></a>
                    </li>
                    <li>
                        <a href="http://blog.creative-tim.com/" target="_blank"><?php echo e(__('Blog')); ?></a>
                    </li>
                    <li>
                        <a href="https://www.creative-tim.com/license" target="_blank"><?php echo e(__('Licenses')); ?></a>
                    </li>
                </ul>
            </nav>
            <div class="credits ml-auto">
                <span class="copyright">
                    ©
                    <script>
                    document.write(new Date().getFullYear())
                    </script><?php echo e(__(', made with ')); ?><i class="fa fa-heart heart"></i><?php echo e(__(' by ')); ?><a
                        class="<?php if(Auth::guest()): ?> text-white <?php endif; ?>" href="https://www.creative-tim.com"
                        target="_blank"><?php echo e(__('Yutaka Team')); ?></a><?php echo e(__(' and ')); ?><a
                        class="<?php if(Auth::guest()): ?> text-white <?php endif; ?>" target="_blank"
                        href="https://updivision.com"><?php echo e(__('UPDIVISION')); ?></a>
                </span>
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\Users\MUH. FAHRUL\OneDrive\Documents\Project\incomingApp\resources\views/layouts/footer.blade.php ENDPATH**/ ?>