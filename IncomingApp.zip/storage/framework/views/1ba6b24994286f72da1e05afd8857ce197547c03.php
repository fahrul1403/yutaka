<div class="sidebar" data-color="white" data-active-color="danger">
    <div class="logo">
        <a href="http://www.creative-tim.com" class="simple-text logo-mini">
            <div class="logo-image-small">
                <img src="<?php echo e(asset('paper')); ?>/img/logo-small.png">
            </div>
        </a>
        <a href="http://www.creative-tim.com" class="simple-text logo-normal">
            <?php echo e(__('Yutaka Tim')); ?>

        </a>
    </div>
    <div class="sidebar-wrapper">
        <ul class="nav">
            <li class="<?php echo e($elementActive == 'dashboard' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('page.index', 'dashboard')); ?>">
                    <i class="nc-icon nc-bank"></i>
                    <p><?php echo e(__('Dashboard')); ?></p>
                </a>
            </li>

            <li class="<?php echo e($elementActive == 'tables' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('page.index', 'tables')); ?>">
                    <i class="nc-icon nc-tile-56"></i>
                    <p><?php echo e(__('Supplier table')); ?></p>
                </a>
            </li>
            <li class="<?php echo e($elementActive == 'inspector' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('page.index', 'inspector')); ?>">
                    <i class="nc-icon nc-tile-56"></i>
                    <p><?php echo e(__('Inspector table')); ?></p>
                </a>
            </li>
            <li class="<?php echo e($elementActive == 'user' || $elementActive == 'profile' ? 'active' : ''); ?>">
                <a data-toggle="collapse" aria-expanded="true" href="#laravelExamples">
                    <i class="nc-icon"><img src="<?php echo e(asset('paper/img/laravel.svg')); ?>"></i>
                    <p>
                        <?php echo e(__('USERs')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse show" id="laravelExamples">
                    <ul class="nav">
                        <li class="<?php echo e($elementActive == 'profile' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('profile.edit')); ?>">
                                <span class="sidebar-mini-icon"><?php echo e(__('UP')); ?></span>
                                <span class="sidebar-normal"><?php echo e(__(' User Profile ')); ?></span>
                            </a>
                        </li>

                    </ul>
                </div>
            </li>

        </ul>
    </div>
</div><?php /**PATH C:\Users\MUH. FAHRUL\OneDrive\Documents\Project\incomingApp\resources\views/layouts/navbars/auth.blade.php ENDPATH**/ ?>